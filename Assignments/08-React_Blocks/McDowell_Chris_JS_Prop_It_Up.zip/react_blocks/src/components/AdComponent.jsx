import style from "../css/AdComponent.module.css"

const AdComponent = () => {
    
    return (
        <div className={style.adBox}>
            <p className={style.adText}>Advertisement</p>
        </div>

    )

}

export default AdComponent