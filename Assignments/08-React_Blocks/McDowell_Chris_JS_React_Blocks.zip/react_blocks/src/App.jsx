import './App.css'
import HeaderComponent from './components/HeaderComponent';
import NavComponent from './components/NavComponent';
import MainComponent from './components/MainComponent';
import SubComponent from './components/SubComponent';
import AdComponent from './components/AdComponent';


function App() {
  
  return (
    <>
      <HeaderComponent />
      <div className="row">
          <NavComponent />
          <MainComponent>
            <div className="row">
              <SubComponent />
              <SubComponent />
              <SubComponent />
          </div>
            <AdComponent />
          </MainComponent>
      </div>
    </>
  )
}

export default App;
