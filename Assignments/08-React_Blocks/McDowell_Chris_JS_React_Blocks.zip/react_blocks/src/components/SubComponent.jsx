import style from "../css/SubComponent.module.css"

const SubComponent = () => {

    return (
        <div className={style.subBox}>
            <p className={style.subText}>Sub Content</p>
        </div>
    )
}
export default SubComponent