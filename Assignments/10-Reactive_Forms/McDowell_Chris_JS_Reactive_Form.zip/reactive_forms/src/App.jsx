import { useState } from 'react'
import UserForm from "./components/UserForm"
import './App.css'

function App() {

  return (
    <>
      <UserForm />
    </>
  )
}

export default App
