import React from "react";
import { useState } from "react";
import "./App.css";
import Tabs from "./components/tabs";

function App() {
  return (
    <>
      <Tabs />
    </>
  );
}

export default App;
