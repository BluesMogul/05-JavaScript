import React from "react";
import { useState } from "react";

const DisplayPokemon = () => {
  const [pokemonList, setPokemonList] = useState();

  return (
    <div>
      <p className="pageTitle">POKEMON API</p>
    </div>
  );
};

export default Pokemon;
