import { Link, useNavigate } from "react-router-dom";
// import Choices from "./Choices";

const Home = () => {
  return (
    <div className="container">
      <h1>WELCOME!</h1>
      {/* <Link to="/Choices">
        <br />
        <button>CLICK TO PLAY!</button>
      </Link> */}
    </div>
  );
};

export default Home;
