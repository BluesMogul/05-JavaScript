import { useState } from "react";
import "./App.css";
import { Route, Routes } from "react-router-dom";
// import Nav from "./components/Nav"
// import ChildOne from "./components/ChildOne";
// import ChildTwo from "./components/ChildTwo";

import NewPatientForm from "./components/NewPatientForm";
import DisplayAllPatients from "./components/DisplayAllPatients";
import PatientDetails from "./components/PatientDetails";
import UpdatePatientForm from "./components/UpdatePatientForm";


function App() {

    // State is form input and display appear on the same page.
    // const [liftedState, setLiftedState] = useState([])
    // const stateUpdater = (newValue) => {
    //     setLiftedState((prevLiftedState) => [...prevLiftedState, newValue])
    // }

    return (
        <>
            <Routes>
                <Route index element={<NewPatientForm />}/>
                <Route path='/all/patients' element={<DisplayAllPatients />}/>
                <Route path='/details/patient/:id' element={<PatientDetails />} />
                <Route path='/update/patient/:id' element={<UpdatePatientForm />} />
            </Routes>

            {/* If ChildOne + ChildTwo Display on the same page */}
            {/* <ChildOne stateUpdater={stateUpdater} />
            <ChildTwo liftedState={liftedState} /> */}
        </>
    );
}
export default App;
