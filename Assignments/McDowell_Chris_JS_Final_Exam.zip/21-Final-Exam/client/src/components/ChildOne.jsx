import { useState } from "react";


// This is the input form to be displayed
// in ChildTwo on the same page.
const ChildOne = (props) => {
    const { stateUpdater } = props;

    const [valueOne, setValueOne] = useState('');
    const [valueTwo, setValueTwo] = useState('');

    const submitHandler = (e) => {
        e.preventDefault();

        let newValue = {
            // Key names must match exactly to use
            // shorthand version of these statements:
            valueOne: valueOne,
            valueTwo: valueTwo
        }

        stateUpdater(newValue);
        setValueOne('');
        setValueTwo('')
    }

    return (
        <div>
            <h1>Form</h1>
            <form onSubmit={submitHandler}>
                <label>Value One</label>
                <input type="text" value={valueOne} onChange={(e) => setValueOne(e.target.value)} />
                <label>Value Two</label>
                <input type="text" value={valueTwo} onChange={(e) => setValueTwo(e.target.value)} />
                <button>SUBMIT</button>
            </form>
        </div>
    )
}

export default ChildOne;