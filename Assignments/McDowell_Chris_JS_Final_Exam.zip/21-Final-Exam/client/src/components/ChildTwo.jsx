import { useState } from 'react';

// This is the display results from the input
// from ChildOne

const ChildTwo = (props) => {
    const { liftedState } = props;

    return (
        <div>
            <h1>Child Two</h1>
            {
                liftedState.map((item, index) => (
                    <div key={index}>
                        <p>{item.valueOne}</p>
                        <p>{item.valueTwo}</p>
                    </div>
                ))
            }
        </div>
    )

}
export default ChildTwo;