import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate, useParams, Link } from "react-router-dom";

const DisplayAllPatients = (props) => {
    const [patients, setPatients] = useState([])
    const { id } = useParams();


    useEffect(() => {
        axios.get('http://localhost:8000/api/patient')
            .then((res) => {
            setPatients(res.data)
            })
            .catch((err) => {
            console.log(err)
        })
    }, [])

    return (
        <>
            <header>
                    <nav>
                        <div className="navContainer">
                        <div className="navButtonBox">
                            <button className="staticButton">Home</button>
                            </div>
                        <div className="navVariableHeader">
                                <p className="pageTitle">Hospital Manager</p>
                            </div>
                        <div className="navButtonBox">
                            <Link to={'/'}>
                                <button className="navButton">Admissions</button>
                        </Link>
                        </div>
                        </div>
                    </nav>
                </header>
            <div>
                <p className="displayAllSubTitle">CURRENT PATIENT LIST</p>
            </div>
            <div className="container">
                <table className="table table-bordered table-secondary table-striped">
                    <thead>
                        <tr>
                            <th scope="column">Name</th>
                            <th scope="column">Age</th>
                            <th scope="column">Symptoms</th>
                            <th scope="column">Update</th>
                        </tr>
                    </thead>
                    <tbody className="table-group-divider">
                        {patients.map((patient) => {
                            return (
                                <tr key={patient._id} className="align-middle">
                                    <td className="leftText">
                                        <div>
                                            <Link to={`/details/patient/${patient._id}`}>{patient.patientName}</Link>
                                        </div>
                                        </td>
                                    <td>{patient.patientAge}</td>
                                    <td className="leftText">{patient.patientSymptoms}</td>
                                    <td className="centerButton">
                                        <Link to={`/update/patient/${patient._id}`}>
                                            <button className="detailButton">Update Details</button>
                                        </Link>
                                    </td>
                                </tr>
                            )
                        })}
                    </tbody>
                </table>
            </div>
        </>
)}

export default DisplayAllPatients;