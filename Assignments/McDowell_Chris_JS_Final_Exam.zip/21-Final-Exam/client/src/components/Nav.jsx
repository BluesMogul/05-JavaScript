import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';

function Nav() {


    return (
        <header>
            <nav>
                <div className="navContainer">
                    <div className="navVariableHeader">
                        <p className="pageTitle">This is the Navigation Bar</p>
                    </div>
                    <div className="navButtonBox">
                        <button className="navButton">Show All</button>
                        <button className="navButton">Add Thing</button>
                    </div>
                </div>
            </nav>
        </header>
    );
}
export default Nav;
