import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams, useNavigate, Link } from 'react-router-dom';

const PatientDetails = (props) => {
    const { id } = useParams();
    const [patient, setPatient] = useState({})
    const navigate = useNavigate()

    useEffect(() => {
        axios.get(`http://localhost:8000/api/patient/${id}`)
            .then((res) => {
                setPatient(res.data);
            })
            .catch((err) => {
                console.log(err);
            })
            .catch((err) => {
                console.log(err)
            })
    }, [])

    const deletePatient = (id) => {
        axios.delete(`http://localhost:8000/api/patient/${id}`)
            .then(() => navigate('/'))
        .catch((err) => console.log(err))
    }


    return (
        <>
            <header>
                <nav>
                    <div className="navContainer">
                        <div className="navButtonBox">
                            <Link to={'/all/patients'}>
                                <button className="navButton">Home</button>
                            </Link>
                        </div>
                        <div className="navVariableHeader">
                            <p className="detailsPageTitle">DETAILS FOR</p>
                            <p className="detailsName">{patient.patientName}</p>
                        </div>
                        <div className="navButtonBox">
                            <Link to={`/update/patient/${patient._id}`}>
                                <button className="navButton">Update Details</button>
                            </Link>
                        </div>
                    </div>
                </nav>
            </header>
            <div className="pageCenter">
            <div className="formHeader">
                <p className="subTitle">Patient Details</p>
            </div>
            <div className="formContainer">
                <div className="mb-3">
                    <div className="inputAlign">
                        <label className="input-group-addon">Name:</label>
                        <input type="text" value={patient.patientName} className="form-control" disabled></input>
                    </div>
                <br />
                    <div className="inputAlign">
                        <label className="input-group-addon">Age:</label>
                        <input type="number" value={patient.patientAge} className="form-control" disabled></input>
                    </div>
                <br />
                    <div className="inputAlign">
                        <label className="input-group-addon">Symptoms:</label>
                        <textarea value={patient.patientSymptoms} className="form-control" rows="10" disabled></textarea>
                    </div>
                <br />
                    <div className="formButtonBox">
                        <button className="formButton"
                            onClick={() => deletePatient(patient._id)}>Discharge</button>
                    </div>
                </div>
            </div>
            </div>
        </>
    )
}

export default PatientDetails;