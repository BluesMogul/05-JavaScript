import React, { useState, useEffect } from 'react';
import axios from "axios";
import { useNavigate, useParams, Link } from "react-router-dom";

const UpdatePatientForm = (props) => {
    const navigate = useNavigate();
    const { id } = useParams();
    const [patientName, setPatientName] = useState("");
    const [patientSymptoms, setPatientSymptoms] = useState("");
    const [patientAge, setPatientAge] = useState("");
    // Server Errors
    const [errors, setErrors] = useState({});

    useEffect(() => {
        axios.get(`http://localhost:8000/api/patient/${id}`)
            .then((res) => {
                setPatientName(res.data.patientName)
                setPatientSymptoms(res.data.patientSymptoms)
                setPatientAge(res.data.patientAge)
            })
            .catch((err) => {
            console.log(err);
        })
    }, [])

    // Client Errors
    const [enteredForm, setEnteredForm]= useState(false)
    const [formErrors, setFormErrors] = useState({
        patientName: "",
        patientAge: "",
        patientSymptoms: "",
    });

    // Form Validation
    const validateForm = () => {
        console.log(Object.values(formErrors))
        return Object.values(formErrors).every(value => value === '');
    }

    const patientNameHandler = (e) => {
        setEnteredForm(true);
        setPatientName(e.target.value);
        const value = e.target.value.trim();
        let errorMsg = "";

        if (value) {
            if (value.length <= 0) {
                errorMsg = "Patient name must be at least 1 character in length!";
            } else if (value.length > 40) {
                errorMsg = "Patient name cannot be more than 40 characters in length!";
            }
        } else {
            errorMsg = "Patient name is required!";
        }
        setFormErrors({ ...formErrors, patientName: errorMsg });
    }

    const patientAgeHandler = (e) => {
        setPatientAge(e.target.value);
        const value = e.target.value.trim();
        let errorMsg = "";

        if (value) {
            if (value <= 0) {
                errorMsg = "Patient age must be greater than 0";
            } else if (value > 140) {
                errorMsg = "Patient age cannot be more than 140!";
            }
        } else {
            errorMsg = ""
        }
        setFormErrors({ ...formErrors, patientAge: errorMsg });
    }

    const patientSymptomsHandler = (e) => {
        setPatientSymptoms(e.target.value);
        const value = e.target.value.trim();
        let errorMsg = "Patient symptoms are required!";

        if (value) {
            if (value.length < 4) {
                errorMsg = "Symptoms must be at least 4 characters in length!";
            } else {
                errorMsg = ""
            }
            setFormErrors({ ...formErrors, patientSymptoms: errorMsg });
        }
    }

    // const changeHandler = (e) => {
    //     const { patientName, value } = e.target;
    //     setFormData({ ...FormData, [patientName]: value });
    // }

    const submitHandler = (e) => {
        e.preventDefault();
        const updatedPatient = {
            patientName,
            patientAge,
            patientSymptoms,
        }
        axios.put(`http://localhost:8000/api/patient/${id}`, updatedPatient) // This becomes the req.body that is sent to the DB
            .then((res) => {
                navigate(`/details/patient/${id}`)
            })
            .catch((err) => {
                setErrors(err.response.data.errors);
            })
    }

        return (
            <>
                <header>
                    <nav>
                        <div className="navContainer">
                            <div className="navButtonBox">
                                <Link to={'/'}>
                                    <button className="navButton">Home</button>
                                </Link>
                            </div>
                            <div className="navVariableHeader">
                                <p className="detailsPageTitle">UPDATE DETAILS FOR</p>
                                <p className="detailsName">{patientName}</p>
                            </div>
                            <div className="navButtonBox">
                                <Link to={`/details/patient/${id}`}>
                                <button className="navButton">Details Only</button>
                                </Link>
                            </div>
                        </div>
                    </nav>
                </header>
                <div className="pageCenter">
                <div className="formHeader">
                    <p className="subTitle">UPDATE PATIENT INFORMATION</p>
                </div>
                <div className="formContainer">
                    <form onSubmit={submitHandler}>
                        <div className="mb-3">
                            <div className="inputAlign">
                                <label className="input-group-addon">Name:</label>
                                <input type="text" value={patientName} className="form-control" name="patientName"
                                    onChange={patientNameHandler} placeholder="Patient Name" />
                            </div>
                            <div>
                                {/* front-end errors */}
                                {formErrors.patientName && <p className={enteredForm ? "errorMessage" : "hidden"}> {formErrors.patientName}</p>}

                                {/* back-end errors */}
                                {errors.patientName ? <p className="errorText">{errors.patientName.message}</p> : null}
                            </div>
                            <div className="spacer">&nbsp;</div>
                            <div className="inputAlign">
                                <label className="input-group-addon">Age:</label>
                                <input type="number" value={patientAge} className="form-control" name="patientAge"
                                    onChange={patientAgeHandler} placeholder="Patient Age" />
                            </div>
                            <div>
                                {/* front-end errors */}
                                {formErrors.patientAge && (
                                    <p className="errorText">{formErrors.patientAge}</p>
                                )}
                                {/* back-end errors */}
                                {errors.patientAge ? <p className="errorText">{errors.patientAge.message}</p> : null}
                            </div>
                            <div className="spacer">&nbsp;</div>
                            <div className="inputAlign">
                                <label className="input-group-addon">Symptoms:</label>
                                <textarea rows="10" value={patientSymptoms} className="form-control" name="patientSymptoms"
                                    onChange={patientSymptomsHandler} placeholder="Patient Symptoms" />
                            </div>
                            <div>
                                {/* front-end errors */}
                                {formErrors.patientSymptoms && (
                                    <p className="errorText">{formErrors.patientSymptoms}</p>
                                )}
                                {/* back-end errors */}
                                {errors.patientSymptoms ? <p className="errorText">{errors.patientSymptoms.message}</p> : null}
                            </div>
                            <div className="spacer">&nbsp;</div>
                        </div>
                        <div className="formButtonBox">
                            <button className="navButton">Update Details</button>
                        </div>
                    </form>
                </div>
                </div>
            </>
        )
    }

export default UpdatePatientForm