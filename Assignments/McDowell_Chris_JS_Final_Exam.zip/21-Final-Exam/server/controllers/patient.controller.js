import Patient from "../models/patient.model.js";

export const patientController = {
// CREATE: Create New Patient
    createPatient: async (req, res) => {
        try {
            const newPatient = await Patient.create(req.body) // creates new thing with ID and timestamps
            console.log(newPatient);
            return res.status(201).json(newPatient)
        } catch (error) {
            return res.status(500).json(error)
        }
    },

 //READ: ALL Patients
    getAllPatients: async (req, res) => {
        try {
            const allPatients = await Patient.find();
            return res.status(200).json(allPatients)
        } catch (error) {
            return res.status(500).json(error)
        }
    },

 //READ: One Patient by ID
    getOnePatient: async (req, res) => {
        try {
            const id = req.params.id
            const onePatient = await Patient.findById(id)
            return res.status(200).json(onePatient)
        } catch (error) {
            return res.status(500).json(error)
        }
    },

//UPDATE: Update One Patient by ID
    updatePatient: async (req, res) => {
        try {
            const options = {
                new: true, // This makes mongoose return the updated doc after updating
                runValidators: true, // Runs validations same as create
            }
            const id = req.params.id
            const updatedPatient = await Patient.findByIdAndUpdate(id, req.body, options)
            return res.status(201).json(updatedPatient)
        } catch (error) {
            return res.status(500).json(error)
        }
    },

//DELETE: Delete One Patient by ID
    deletePatient: async (req, res) => {
        try {
            const id = req.params.id
            const deletedPatient = await Patient.findByIdAndDelete(id)
            return res.status(204).send()
        } catch (error) {
            return res.status(500).json(error)
        }
    },
}