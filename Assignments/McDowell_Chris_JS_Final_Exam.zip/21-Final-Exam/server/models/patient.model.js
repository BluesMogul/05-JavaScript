import { model, Schema } from 'mongoose';

const PatientSchema = new Schema(
    {
        patientName: {
            type: String,
            required: [true, "** Patient name is required! **"],
            minlength: [1, "** Patient name must be at least 1 character. **"],
            maxlength: [40, "** Patient name cannot be more than 40 characters in length. **"]
        },
        patientAge: {
            type: Number,
            required: [true, "** Patient age is required! **"],
            min: [1, "** Book must have at least one page! **"],
            max: [140, "** Patient's age cannot be greater than 140! **"]
        },
        patientSymptoms: {
            type: String,
            required: [true, "** Patient symptoms are required! **"],
            minlength: [4, "** Description of patient symptoms must be at least 4 characters in length! **"],
        },
    },
    { timestamps: true }
);
const Patient = model("Patient", PatientSchema);

export default Patient;
