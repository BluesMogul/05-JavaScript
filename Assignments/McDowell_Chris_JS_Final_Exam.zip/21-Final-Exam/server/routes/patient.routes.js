import { Router } from 'express';
import { patientController } from "../controllers/patient.controller.js";

const router = Router();

router.route('/patient')
    .post(patientController.createPatient)
    .get(patientController.getAllPatients)

router.route('/patient/:id')
    .get(patientController.getOnePatient)
    .delete(patientController.deletePatient)
    .put(patientController.updatePatient)

export default router;