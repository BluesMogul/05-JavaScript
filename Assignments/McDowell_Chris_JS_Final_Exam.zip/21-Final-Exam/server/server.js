import express from 'express';
import dotenv from 'dotenv';
import cors from 'cors';
import dbConnect from './config/mongoose.config.js'

import patientRoutes from "./routes/patient.routes.js"

const app = express();

app.use(express.json(), cors({origin: "http://localhost:5173"}));
app.use("/api", patientRoutes);

dotenv.config();
const PORT = process.env.PORT;

dbConnect() // Connect to the database

// Start the server and listen on specified port from environment variables
app.listen(PORT, () => console.log("Server is running on port " + PORT));